package com.prueba.nexos.inventario.service;

import com.prueba.nexos.inventario.entities.Salida;
import org.springframework.data.domain.Page;

public interface SalidaService {

  Salida crear(Salida salida);
}

