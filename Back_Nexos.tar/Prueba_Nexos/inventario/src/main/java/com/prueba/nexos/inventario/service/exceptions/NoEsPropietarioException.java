package com.prueba.nexos.inventario.service.exceptions;

public class NoEsPropietarioException extends RuntimeException{

  public NoEsPropietarioException(String message) {
    super(message);
  }
}
