package com.prueba.nexos.inventario.service;

import com.prueba.nexos.inventario.entities.Ingreso;

public interface IngresoService {

  Ingreso crear(Ingreso ingreso);
}
