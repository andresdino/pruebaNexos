package com.prueba.nexos.inventario.service.exceptions;

public class ObjetoExistenteException extends RuntimeException {

  public ObjetoExistenteException(String message) {
    super(message);
  }
}
