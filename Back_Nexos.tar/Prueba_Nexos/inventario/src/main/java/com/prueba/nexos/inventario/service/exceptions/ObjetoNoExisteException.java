package com.prueba.nexos.inventario.service.exceptions;

public class ObjetoNoExisteException extends RuntimeException {

  public ObjetoNoExisteException(String message) {
    super(message);
  }
}
